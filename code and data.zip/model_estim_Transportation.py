# -*- coding: utf-8 -*-
"""
Created on Tue May 10 12:12:27 2022

@author: JMC
"""
import datetime 
import time
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from linearmodels.panel import PanelOLS,PooledOLS
import seaborn as sns
import statsmodels.api as sm
# in the same directory where the data and the py file are stored, a directory /results and a directory /plot  should be created to store the output summary results and figures respectively 

#load data. I
datospanel=pd.read_csv('datapanel_traffic.csv')
datospanel['fecha2']=pd.to_datetime(datospanel.fecha2)

datospanel=datospanel.set_index(['id',datospanel.index])
variables=['hora1_p_central', 'hora2_p_central', 'hora3_p_central', 'hora4_p_central', 'hora5_p_central', 'hora6_p_central', 'hora7_p_central', 'hora8_p_central', 'hora9_p_central', 'hora10_p_central', 'hora11_p_central', 'hora12_p_central', 'hora13_p_central', 'hora14_p_central', 'hora15_p_central', 'hora16_p_central', 'hora17_p_central', 'hora18_p_central', 'hora19_p_central', 'hora20_p_central', 'hora21_p_central', 'hora22_p_central', 'hora23_p_central', 'MC2019p_central', 'hora1_p_border_central', 'hora2_p_border_central', 'hora3_p_border_central', 'hora4_p_border_central', 'hora5_p_border_central', 'hora6_p_border_central', 'hora7_p_border_central', 'hora8_p_border_central', 'hora9_p_border_central', 'hora10_p_border_central', 'hora11_p_border_central', 'hora12_p_border_central', 'hora13_p_border_central', 'hora14_p_border_central', 'hora15_p_border_central', 'hora16_p_border_central', 'hora17_p_border_central', 'hora18_p_border_central', 'hora19_p_border_central', 'hora20_p_border_central', 'hora21_p_border_central', 'hora22_p_border_central', 'hora23_p_border_central', 'MC2019p_border_central', 'hora1_p_in_M30', 'hora2_p_in_M30', 'hora3_p_in_M30', 'hora4_p_in_M30', 'hora5_p_in_M30', 'hora6_p_in_M30', 'hora7_p_in_M30', 'hora8_p_in_M30', 'hora9_p_in_M30', 'hora10_p_in_M30', 'hora11_p_in_M30', 'hora12_p_in_M30', 'hora13_p_in_M30', 'hora14_p_in_M30', 'hora15_p_in_M30', 'hora16_p_in_M30', 'hora17_p_in_M30', 'hora18_p_in_M30', 'hora19_p_in_M30', 'hora20_p_in_M30', 'hora21_p_in_M30', 'hora22_p_in_M30', 'hora23_p_in_M30', 'MC2019p_in_M30', 'hora1_p_out_M30', 'hora2_p_out_M30', 'hora3_p_out_M30', 'hora4_p_out_M30', 'hora5_p_out_M30', 'hora6_p_out_M30', 'hora7_p_out_M30', 'hora8_p_out_M30', 'hora9_p_out_M30', 'hora10_p_out_M30', 'hora11_p_out_M30', 'hora12_p_out_M30', 'hora13_p_out_M30', 'hora14_p_out_M30', 'hora15_p_out_M30', 'hora16_p_out_M30', 'hora17_p_out_M30', 'hora18_p_out_M30', 'hora19_p_out_M30', 'hora20_p_out_M30', 'hora21_p_out_M30', 'hora22_p_out_M30', 'hora23_p_out_M30', 'MC2019p_out_M30', 'month1', 'month2', 'month3', 'month4', 'month5', 'month6', 'month7', 'month8', 'month9', 'month10', 'month11', 'year2014', 'year2015', 'year2016', 'year2017', 'year2018', 'year2019']
variables2=[ 'hora1_p_central', 'hora2_p_central', 'hora3_p_central', 'hora4_p_central', 'hora5_p_central', 'hora6_p_central', 'hora7_p_central', 'hora8_p_central', 'hora9_p_central', 'hora10_p_central', 'hora11_p_central', 'hora12_p_central', 'hora13_p_central', 'hora14_p_central', 'hora15_p_central', 'hora16_p_central', 'hora17_p_central', 'hora18_p_central', 'hora19_p_central', 'hora20_p_central', 'hora21_p_central', 'hora22_p_central', 'hora23_p_central', 'MC2019p_central', 'hora1_p_border_central', 'hora2_p_border_central', 'hora3_p_border_central', 'hora4_p_border_central', 'hora5_p_border_central', 'hora6_p_border_central', 'hora7_p_border_central', 'hora8_p_border_central', 'hora9_p_border_central', 'hora10_p_border_central', 'hora11_p_border_central', 'hora12_p_border_central', 'hora13_p_border_central', 'hora14_p_border_central', 'hora15_p_border_central', 'hora16_p_border_central', 'hora17_p_border_central', 'hora18_p_border_central', 'hora19_p_border_central', 'hora20_p_border_central', 'hora21_p_border_central', 'hora22_p_border_central', 'hora23_p_border_central', 'MC2019p_border_central', 'hora1_p_in_M30', 'hora2_p_in_M30', 'hora3_p_in_M30', 'hora4_p_in_M30', 'hora5_p_in_M30', 'hora6_p_in_M30', 'hora7_p_in_M30', 'hora8_p_in_M30', 'hora9_p_in_M30', 'hora10_p_in_M30', 'hora11_p_in_M30', 'hora12_p_in_M30', 'hora13_p_in_M30', 'hora14_p_in_M30', 'hora15_p_in_M30', 'hora16_p_in_M30', 'hora17_p_in_M30', 'hora18_p_in_M30', 'hora19_p_in_M30', 'hora20_p_in_M30', 'hora21_p_in_M30', 'hora22_p_in_M30', 'hora23_p_in_M30', 'MC2019p_in_M30', 'hora1_p_out_M30', 'hora2_p_out_M30', 'hora3_p_out_M30', 'hora4_p_out_M30', 'hora5_p_out_M30', 'hora6_p_out_M30', 'hora7_p_out_M30', 'hora8_p_out_M30', 'hora9_p_out_M30', 'hora10_p_out_M30', 'hora11_p_out_M30', 'hora12_p_out_M30', 'hora13_p_out_M30', 'hora14_p_out_M30', 'hora15_p_out_M30', 'hora16_p_out_M30', 'hora17_p_out_M30', 'hora18_p_out_M30', 'hora19_p_out_M30', 'hora20_p_out_M30', 'hora21_p_out_M30', 'hora22_p_out_M30', 'hora23_p_out_M30', 'MC2019p_out_M30', 'intetot']
variables3=['hora1_p_central', 'hora2_p_central', 'hora3_p_central', 'hora4_p_central', 'hora5_p_central', 'hora6_p_central', 'hora7_p_central', 'hora8_p_central', 'hora9_p_central', 'hora10_p_central', 'hora11_p_central', 'hora12_p_central', 'hora13_p_central', 'hora14_p_central', 'hora15_p_central', 'hora16_p_central', 'hora17_p_central', 'hora18_p_central', 'hora19_p_central', 'hora20_p_central', 'hora21_p_central', 'hora22_p_central', 'hora23_p_central', 'MC2019p_central', 'hora1_p_border_central', 'hora2_p_border_central', 'hora3_p_border_central', 'hora4_p_border_central', 'hora5_p_border_central', 'hora6_p_border_central', 'hora7_p_border_central', 'hora8_p_border_central', 'hora9_p_border_central', 'hora10_p_border_central', 'hora11_p_border_central', 'hora12_p_border_central', 'hora13_p_border_central', 'hora14_p_border_central', 'hora15_p_border_central', 'hora16_p_border_central', 'hora17_p_border_central', 'hora18_p_border_central', 'hora19_p_border_central', 'hora20_p_border_central', 'hora21_p_border_central', 'hora22_p_border_central', 'hora23_p_border_central', 'MC2019p_border_central', 'hora1_p_in_M30', 'hora2_p_in_M30', 'hora3_p_in_M30', 'hora4_p_in_M30', 'hora5_p_in_M30', 'hora6_p_in_M30', 'hora7_p_in_M30', 'hora8_p_in_M30', 'hora9_p_in_M30', 'hora10_p_in_M30', 'hora11_p_in_M30', 'hora12_p_in_M30', 'hora13_p_in_M30', 'hora14_p_in_M30', 'hora15_p_in_M30', 'hora16_p_in_M30', 'hora17_p_in_M30', 'hora18_p_in_M30', 'hora19_p_in_M30', 'hora20_p_in_M30', 'hora21_p_in_M30', 'hora22_p_in_M30', 'hora23_p_in_M30', 'MC2019p_in_M30', 'hora1_p_out_M30', 'hora2_p_out_M30', 'hora3_p_out_M30', 'hora4_p_out_M30', 'hora5_p_out_M30', 'hora6_p_out_M30', 'hora7_p_out_M30', 'hora8_p_out_M30', 'hora9_p_out_M30', 'hora10_p_out_M30', 'hora11_p_out_M30', 'hora12_p_out_M30', 'hora13_p_out_M30', 'hora14_p_out_M30', 'hora15_p_out_M30', 'hora16_p_out_M30', 'hora17_p_out_M30', 'hora18_p_out_M30', 'hora19_p_out_M30', 'hora20_p_out_M30', 'hora21_p_out_M30', 'hora22_p_out_M30', 'hora23_p_out_M30', 'MC2019p_out_M30', 'intetot', 'intetp_central', 'intetp_border_central', 'intetp_in_M30']
 

exogv0=sm.add_constant(datospanel[variables])  #Model version 1
exogv1=sm.add_constant(datospanel[variables2]) #Model version 2a
exogv2=sm.add_constant(datospanel[variables3])   ##Model version 2b


#tables with model version 1 estimated coeff. are saved in file summ_v1.xlsx
writer = pd.ExcelWriter('./results/summ_model_v1.xlsx', engine='xlsxwriter')
list_exog=[exogv0]
pepe=0

for i in list_exog:
    time.sleep(1)
    
    mod = PanelOLS(datospanel['0'], i, entity_effects=True)
    time.sleep(1)

    mod1 = PooledOLS(datospanel['0'], i)
    time.sleep(1)
    
    
    nono=mod.fit(cov_type='clustered',cluster_entity=True)
    nono1=mod1.fit(cov_type='clustered', cluster_entity=True)
    
    #Model predictions 
    y_prd=nono.predict(effects=True)
    y_prd=y_prd.reset_index().merge(datospanel.reset_index(), left_on='time',right_on='level_1')
    y_prd=y_prd.rename(columns={"fecha2": "date"})
    y_prd['MC start']=np.where(y_prd.date<np.datetime64(datetime.date(2019,3,16)) ,'PRE','POST')
    y_prd['month_year']=y_prd.date.dt.year.astype(str)+'_'+y_prd.date.dt.month.astype(str)*(y_prd.date.dt.month>9)+('0'+y_prd.date.dt.month.astype(str))*(y_prd.date.dt.month<=9)
    y_prd['fitted']=y_prd['fitted_values']+y_prd['estimated_effects']
    y_prd['actual']=y_prd['0']
    y_prd['year']=y_prd.date.dt.year
    y_prd['month']=y_prd.date.dt.month
    
    font = {'family': 'calibri',
        
        'weight': 'normal',
        'size': 9,
        }
    f,ax=plt.subplots()
    ax.xaxis.set_major_locator(plt.MaxNLocator(24))
    paraplot=pd.pivot_table(y_prd,index=['month_year'], columns='id_x', values='fitted', aggfunc='mean').reset_index()
    plt.plot(paraplot.month_year.unique(), paraplot[['p_central','p_border_central','p_in_M30','p_out_M30']], label=['p_central','p_border_central','p_in_M30','p_out_M30'])
    plt.axvline(x="2019_03", color='black', linestyle=":",label='MC start')    
    plt.legend(fontsize=8, prop=font)
    plt.grid(visible=False)
    plt.xticks(rotation=90, fontsize=8, font=font)
    plt.yticks( fontsize=8, font=font)
    plt.savefig('./plot/fig 12a.pdf',bbox_inches='tight')
    plt.close()
    
    y_prd= y_prd.set_index('date')
    for area in ['p_central','p_border_central']:
        dataplot=y_prd[y_prd.id_x==area]
        dataplot=dataplot[(dataplot.index.year>2017)&(dataplot.index.hour>6)&(dataplot.index.hour<23)]
        dataplot=pd.DataFrame(data=dataplot.groupby(['MC',dataplot.index.hour])['fitted'].mean().reset_index())
        dataplot.columns=['MC','Hour','fitted']
        sns.set_theme(style="whitegrid")
        g=sns.lineplot(x='Hour', y='fitted', style='MC',markers=True,dashes=False,
               data=dataplot)       
        g.set(ylabel='Hourly Traffic Intensity')
        g.set_ylim(400,850)
        if area=='p_out_M30':
            g.set_ylim(100,500)
    
        g.set(title=area) 
        plt.xticks(rotation=90)             
        plt.savefig('./plot/fig_hour_{cosa}.pdf'.format(cosa=area),bbox_inches='tight')
        plt.close()
    
   

    pd.read_html(nono.summary.as_html(), header=0, index_col=0)[0].to_excel(writer,sheet_name="head{moto}".format(moto=str(pepe)), index=True)
    pepe=pepe+1
    pd.read_html(nono.summary.as_html(), header=0, index_col=0)[1].to_excel(writer,sheet_name="head{moto}".format(moto=str(pepe)), index=True)
    
    pepe=pepe+1
    pd.read_html(nono1.summary.as_html(), header=0, index_col=0)[0].to_excel(writer,sheet_name="head{moto}".format(moto=str(pepe)), index=True)
    pepe=pepe+1
    pd.read_html(nono1.summary.as_html(), header=0, index_col=0)[1].to_excel(writer,sheet_name="head{moto}".format(moto=str(pepe)), index=True)
    
    pepe=pepe+1
    
writer.save()



writer = pd.ExcelWriter('./results/summ_model_v2.xlsx', engine='xlsxwriter')
list_exog=[exogv1,exogv2]
pepe=0
pon='b'
for i in list_exog:

    
    mod2 = PanelOLS(datospanel['0'], i, entity_effects=True)
    time.sleep(1)

    mod3 = PooledOLS(datospanel['0'], i)
    time.sleep(1)
    
    
    nono2=mod2.fit(cov_type='robust', entity_effects=True)
    nono3=mod3.fit(cov_type='robust', entity_effects=True)
    
      
    y_prd=nono2.predict(effects=True)
    y_prd=y_prd.reset_index().merge(datospanel.reset_index(), left_on='time',right_on='level_1')
    y_prd=y_prd.rename(columns={"fecha2": "date"})
    y_prd['MC']=np.where(y_prd.date<np.datetime64(datetime.date(2019,3,16)) ,'PRE','POST')
    y_prd['month_year']=y_prd.date.dt.year.astype(str)+'_'+y_prd.date.dt.month.astype(str)*(y_prd.date.dt.month>9)+('0'+y_prd.date.dt.month.astype(str))*(y_prd.date.dt.month<=9)
    y_prd['fitted']=y_prd['fitted_values']+y_prd['estimated_effects']
    y_prd['actual']=y_prd['0']
    y_prd['year']=y_prd.date.dt.year
    y_prd['month']=y_prd.date.dt.month
    
    sns.set(style="white")
    f,ax=plt.subplots()
    ax.xaxis.set_major_locator(plt.MaxNLocator(24))
    paraplot=pd.pivot_table(y_prd,index=['month_year'], columns='id_x', values='fitted', aggfunc='mean').reset_index()
    plt.plot(paraplot.month_year.unique(), paraplot[['p_central','p_border_central','p_in_M30','p_out_M30']], label=['p_central','p_border_central','p_in_M30','p_out_M30'])
    plt.axvline(x="2019_03", color='black', linestyle=":",label='MC start')    
    plt.legend(fontsize=8, prop=font)
    plt.grid(visible=False)
    plt.xticks(rotation=90, fontsize=8, font=font)
    plt.yticks( fontsize=8, font=font)
    
    plt.savefig('./plot/fig_12{pon}.pdf'.format(pon=pon),bbox_inches='tight')
    plt.close()
    y_prd= y_prd.set_index('date')
    
    
    for area in ['p_central','p_border_central']:
    
        dataplot=y_prd[y_prd.id_x==area]
        dataplot=dataplot[(dataplot.index.year>2017)&(dataplot.index.hour>6)&(dataplot.index.hour<23)]
        dataplot=pd.DataFrame(data=dataplot.groupby(['MC',dataplot.index.hour])['fitted'].mean().reset_index())
        dataplot.columns=['MC','Hour','fitted']
        sns.set_theme(style="whitegrid")
        g=sns.lineplot(x='Hour', y='fitted', style='MC',markers=True,dashes=False,
               data=dataplot)       
        g.set(ylabel='Hourly Traffic Intensity')
        g.set_ylim(400,850)
        if area=='p_out_M30':
            g.set_ylim(100,500)

   
        g.set(title=area) 
        plt.xticks(rotation=90)             
        plt.savefig('./plot/fig_hour_v2{pon}_{cosa}_{pepe}.pdf'.format(pon=pon,cosa=area,pepe=str(pepe)),bbox_inches='tight')
        plt.close()
        
    pd.read_html(nono2.summary.as_html(), header=0, index_col=0)[0].to_excel(writer,sheet_name="head{moto}".format(moto=str(pepe)), index=True)
    pepe=pepe+1
    pd.read_html(nono2.summary.as_html(), header=0, index_col=0)[1].to_excel(writer,sheet_name="head{moto}".format(moto=str(pepe)), index=True)
    time.sleep(1)

    pepe=pepe+1
    pd.read_html(nono3.summary.as_html(), header=0, index_col=0)[0].to_excel(writer,sheet_name="head{moto}".format(moto=str(pepe)), index=True)
    pepe=pepe+1
    pd.read_html(nono3.summary.as_html(), header=0, index_col=0)[1].to_excel(writer,sheet_name="head{moto}".format(moto=str(pepe)), index=True)
    pon='c'
    pepe=pepe+1
    
writer.save()



